/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uma36
 */

import java.sql.*;
public class Connector {
		public static Connection getConnection() throws Exception
		
		{
			Class.forName("oracle.jdbc.OracleDriver");
			Connection cn=(Connection)
				DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it207373056","vasavi");
    
                
                return cn;
                }
}

